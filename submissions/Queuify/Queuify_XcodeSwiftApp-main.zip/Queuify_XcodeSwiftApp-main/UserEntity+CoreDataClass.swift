//
//  UserEntity+CoreDataClass.swift
//  Queue
//
//  Created by Zhao, Jennifer (OXF) Student on 11/07/2024.
//
//

import Foundation
import CoreData


public class UserEntity: NSManagedObject {
    @NSManaged public var userIDE: String?
}

